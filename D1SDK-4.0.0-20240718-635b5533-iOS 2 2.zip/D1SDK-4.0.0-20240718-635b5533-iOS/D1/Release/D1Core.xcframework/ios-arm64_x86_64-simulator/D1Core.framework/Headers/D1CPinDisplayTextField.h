//
//
// Copyright © 2022 THALES. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

__attribute__((visibility("default")))
@interface D1CPinDisplayTextField : UITextField

@end

NS_ASSUME_NONNULL_END
