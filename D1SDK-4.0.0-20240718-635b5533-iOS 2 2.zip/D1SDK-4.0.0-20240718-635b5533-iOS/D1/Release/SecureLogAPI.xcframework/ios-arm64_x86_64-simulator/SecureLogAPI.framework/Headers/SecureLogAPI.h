//
//
// Copyright © 2022 THALES. All rights reserved.
//
    

#import <Foundation/Foundation.h>

//! Project version number for SecureLogAPI_Dynamic.
FOUNDATION_EXPORT double SecureLogAPI_DynamicVersionNumber;

//! Project version string for SecureLogAPI_Dynamic.
FOUNDATION_EXPORT const unsigned char SecureLogAPI_DynamicVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SecureLogAPI_Dynamic/PublicHeader.h>

#import <SecureLogAPI/SecureLog.h>
#import <SecureLogAPI/SecureLogConfig.h>
